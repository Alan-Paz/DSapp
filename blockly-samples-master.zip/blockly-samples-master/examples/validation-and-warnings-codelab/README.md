Starter code and completed code for the [codelab](https://blocklycodelabs.dev/codelabs/validation-and-warnings/index.html) on how to validate blocks and display warnings.

The completed code enforces that blocks are valid or displays warnings on invalid blocks.
