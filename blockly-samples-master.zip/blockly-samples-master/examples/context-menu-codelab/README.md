Starter code and completed code for the [codelab](https://blocklycodelabs.dev/codelabs/context-menu-option/index.html) on context menu options.

The completed code adds context menu options that show how to use precondition, scope, callbacks, and more.
